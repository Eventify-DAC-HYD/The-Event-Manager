import React, { Component } from "react";
import FlightService from "./updateService";

class Updateflightcomponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      id: this.props.match.params.id,
      operatingAirlines: "",
      departureCity: "",
      arrivalCity: "",
      dateOfDeparture: "",
    };
    this.changeoperatingAirlinesHandler =
      this.changeoperatingAirlinesHandler.bind(this);
    this.changedepartureCityHandler =
      this.changedepartureCityHandler.bind(this);
    this.changearrivalCityhandler = this.changearrivalCityhandler.bind(this);
    this.changedateOfDeparturehandler = this.dateOfDeparture.bind(this);
  }

  componentDidMount() {
    FlightService.getFlightById(this.state.flightId).then((res) => {
      let airline_flight = res.data;
      this.setState({
        operatingAirlines: airline_flight.operatingAirlines,
        departureCity: airline_flight.departureCity,
        arrivalCity: airline_flight.arrivalCity,
        dateOfDeparture: airline_flight.dateOfDeparture,
      });
    });
  }

  updateFlight = (e) => {
    e.preventDefault();
    let airline_flight = {
      operatingAirlines: this.state.operatingAirlines,
      departureCity: this.state.departureCity,
      arrivalCity: this.state.arrivalCity,
      dateOfDeparture: this.state.dateOfDeparture,
    };
    console.log("airline_flight => " + JSON.stringify(airline_flight));
    // console.log("flightId => " + JSON.stringify(this.state.flightId));

    FlightService.updateFlight(airline_flight, this.state.flightId).then(
      (res) => {
        this.props.history.push("/enterflightdetails");
      }
    );
  };

  changeoperatingAirlinesHandler = (event) => {
    this.setState({ operatingAirlines: event.target.value });
  };

  changedepartureCityHandler = (event) => {
    this.setState({ departureCity: event.target.value });
  };

  changearrivalCityhandler = (event) => {
    this.setState({ arrivalCity: event.target.value });
  };
  changedateOfDeparturehandler = (event) => {
    this.setState({ dateOfDeparture: event.target.value });
  };
  cancel() {
    this.props.history.push("/enterflightdetails");
  }

  render() {
    return (
      <div>
        <br></br>
        <div className="container">
          <div className="row">
            <div className="card col-md-6 offset-md-3 offset-md-3">
              <h3 className="text-center">Update Employee</h3>
              <div className="card-body">
                <form>
                  <div className="form-group">
                    <label> First Name: </label>
                    <input
                      placeholder="airline"
                      name="firstName"
                      className="form-control"
                      value={this.state.operatingAirlines}
                      onChange={this.changeoperatingAirlinesHandler}
                    />
                  </div>
                  <div className="form-group">
                    <label> departure city : </label>
                    <input
                      placeholder="Last Name"
                      name="lastName"
                      className="form-control"
                      value={this.state.departureCity}
                      onChange={this.changedepartureCityHandler}
                    />
                  </div>
                  <div className="form-group">
                    <label> arrival city </label>
                    <input
                      placeholder="Email Address"
                      name="emailId"
                      className="form-control"
                      value={this.state.arrivalCity}
                      changearrivalCityhandler
                    />
                  </div>
                  <div className="form-group">
                    <label> date of arrival</label>
                    <input
                      placeholder="Email Address"
                      name="emailId"
                      className="form-control"
                      value={this.state.dateOfDeparture}
                      changedateOfDeparturehandler
                    />
                  </div>

                  <button
                    className="btn btn-success"
                    onClick={this.updateEmployee}
                  >
                    Save
                  </button>
                  <button
                    className="btn btn-danger"
                    onClick={this.cancel.bind(this)}
                    style={{ marginLeft: "10px" }}
                  >
                    Cancel
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Updateflightcomponent;
