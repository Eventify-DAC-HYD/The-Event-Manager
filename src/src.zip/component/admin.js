import FlightList from "./TableOfFlights.js";
import UserList from "./passanger";
import Mycom from "./Navbar";
import AdminNavbar from "./admin";

export default function Admin() {
  return (
    <>
      <div className="container-fluid">
        <div>
          <AdminNavbar />
        </div>
      </div>
    </>
  );
}
