import React, { Component } from "react";
import getFlight from "./services";
import { Link } from "react-router-dom";

class ListFlightComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      airline_flight: [],
    };
    this.bookFlight = this.bookFlight.bind(this);
  }

  bookFlight(flightId) {}

  componentDidMount() {
    getFlight.getResidents().then((res) => {
      this.setState({ airline_flight: res.data });
    });
  }

  // addResidents() {
  //   this.props.history.push("/add-residents");
  // }
  render() {
    return (
      <div>
        <h2 className="text-center">CHOOSE YOUR FLIGHT USING ID AND BOOK</h2>
        <div className="row">
          <button className="btn btn-primary">BOOK</button>
        </div>
        <div className="row">
          <table className="table table-stripped table-bordered">
            <thead>
              <tr>
                <th>Flight Id</th>
                <th>Airlin Name</th>
                <th>departure city</th>
                <th>arrival city </th>
                <th>date of departure</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {this.state.airline_flight.map((airline_flight) => (
                <tr>
                  <td>{airline_flight.flightId}</td>
                  <td>{airline_flight.operatingAirlines}</td>
                  <td>{airline_flight.departureCity}</td>
                  <td>{airline_flight.arrivalCity}</td>
                  <td>{airline_flight.dateOfDeparture}</td>
                  <td>
                    <Link
                      to="/add-passanger"
                      class="text-decoration-none fs-5 ms-3 "
                    >
                      <button
                        onClick={() => this.bookFlight(airline_flight.flightId)}
                        className="btn btn-info "
                      >
                        Book
                      </button>
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default ListFlightComponent;
