import axios from "axios";
const Flight_API_BASE_URL = "http://localhost:8080/allflight";

class getFlight {
  getResidents() {
    return axios.get(Flight_API_BASE_URL);
  }
}

export default new getFlight();
