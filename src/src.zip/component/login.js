import Mycom from "./Navbar";
import { useState } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import add_url from "../api/api1";
import swal from "sweetalert2";

export default function Login() {
  const [user, setUser] = useState({});
  const [password, setPassword] = useState({});
  let navigate = useNavigate();

  let handleEmail = (e) => setUser(e.target.value);
  let handlePassword = (e) => setPassword(e.target.value);
  let handleForm = (e) => {
    validateUser(user);
    // window.location = "/home";

    // navigate("/home");
  };

  let validateUser = async (user) => {
    let data = { email: user, password: password };
    await axios.post(`${add_url}/login`, data).then((response) => {
      if (response.data.length == 0) {
        swal.fire({
          icon: "error",
          title: "Oops...",
          text: "Wrong Credentials Entered !!",
        });
      } else {
        if (response.data[0].admin == true) {
          window.location = "/admin";
          sessionStorage.setItem("admin", "admin");
        } else {
          sessionStorage.setItem("username", response.data[0].name);
          const userdata = {
            name: response.data[0].name,
            email: response.data[0].email,
            phone: response.data[0].phone,
          };
          sessionStorage.setItem("userdata", JSON.stringify(userdata));
          sessionStorage.setItem("userSession", response.data[0].email);
          localStorage.setItem("user", response.data[0].email);
          window.location = "/home";
        }
      }
      // window.location = "/home";
    });
  };
  return (
    <div>
      <Mycom />
      <div>
        <form onSubmit={handleForm} className="row bg-3 mt-3">
          <div className="col-3"></div>
          <div className="col-6 ">
            <div className="col-md-12">
              <label for="email" className="form-label fs-5">
                Email-ID
              </label>
              <input
                type="email"
                className="form-control w-75"
                id="email"
                name="email"
                onChange={handleEmail}
                required
              />
            </div>
            <div className="col-md-12 mt-4">
              <label for="password" className="form-label fs-5 ">
                Password
              </label>
              <input
                type="password"
                className="form-control w-75"
                id="password"
                onChange={handlePassword}
                required
              />
            </div>
            <div className="col-md-12 mt-5 text-center">
              <h5 className="fs-5">
                Not Registered??
                <Link to="/register" className="text-decoration-none fs-5">
                  &nbsp; &nbsp;Register here
                </Link>
              </h5>
            </div>
            <div class="col-md-12 mt-5 text-center">
              <Link to="/forget" class="text-decoration-none fs-5 ">
                Forgot password?
              </Link>
            </div>
            <div class="col-md-12 text-center">
              <button
                type="submit"
                class="btn btn-lg btn-primary ps-5 pe-5 p-2  mb-2"
              >
                Login
              </button>
            </div>
          </div>
          <div className="col-3"></div>
        </form>
      </div>
    </div>
  );
}
