import Mycom from "./Navbar";
import HomeSuport from "./homesuport";
import "../css/logincss.css";
import "../css/home.css";
import Footer from "./Footer.js";
import HeaderNavigation from "./header-navigation";

export default function Home() {
  return (
    <>
      <div className="sticky-top">
        <HomeSuport />
        {/* <HeaderNavigation /> */}
      </div>

      {/* <div className=" fixed-bottom">
        
      </div> */}
      <div></div>
      <div>
        <div></div>
        <div className="login-img mt-0">
          <div className="vh-100 d-flex">
            <div className="container w-50 m-auto log"></div>
          </div>
        </div>
        {/* <footer>
          <div>
            <Footer />
          </div>
        </footer> */}
        <div>
          <footer className="home1 fs-6 p-2 flex d-flex justify-content-center">
            @All Rights reserved by Flywings
          </footer>
        </div>
      </div>
    </>
  );
}
