import React from "react";

import { BrowserRouter, Router, Route, Routes, Link } from "react-router-dom";
export default function AdminNavbar() {
  return (
    <div>
      <div className="row ">
        <div className="col-sm-12 bg-primary text-light p-2 fs-2 mb-2 flex d-flex">
          <Link
            to="/admin"
            className="text-decoration-none text-light fs-5 mx-4 text-light p-2 fs-2 mb-2"
          >
            flyWings
          </Link>

          <div className=" row width: 100-wh ms-4">
            <div className="col">
              <Link
                to="/allflightforadmin"
                className="text-decoration-none text-light fs-5"
              >
                ViewFlight
              </Link>
            </div>
            <div className="col">
              <Link
                to="/enterflightdetails
"
                className="text-decoration-none text-light fs-5"
              >
                Addflight
              </Link>
            </div>

            <div className="col">
              <Link to="/" className="text-decoration-none text-light fs-5">
                Logout
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
