import React from "react";

import { Link } from "react-router-dom";
export default function Mycom() {
  return (
    <div>
      <div className="row ">
        <div className="col-sm-12 bg-primary text-light p-2 fs-2 mb-2 flex d-flex">
          <Link
            to="/home"
            className="text-decoration-none text-light fs-5 mx-4 text-light p-2 fs-2 mb-2"
          >
            flyWings
          </Link>

          <div className=" row width: 100-wh ms-4">
            <div className="col">
              <Link
                to="/Register"
                className="text-decoration-none text-light fs-5"
              >
                Register
              </Link>
            </div>

            <div className="col">
              <Link to="/" className="text-decoration-none text-light fs-5">
                Login
              </Link>
              <Link to="/" className="text-decoration-none text-light fs-5">
                Logout
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
