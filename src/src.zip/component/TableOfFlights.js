import React, { Component } from "react";

class FlightList extends Component {
  constructor() {
    super();

    this.state = {
      Flights: [],
    };
  }
  render() {
    return (
      <div>
        <h2 className="text-center">Flight List</h2>
        <div className="row">
          <div className="col-2"></div>
          <div className="col-8">
            <table className="table table-sriped table-bordered">
              <thead>
                <tr>
                  <th>Flight_Id</th>
                  <th>OperatingAirlines</th>
                  <th>DepartureCity</th>
                  <th>ArrivalCity</th>
                  <th>DateOfDeparture</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {this.state.Flights.map((flight) => (
                  <tr key="{flight.id}">
                    <td>{flight.OperatingAirlines}</td>
                    <td>{flight.DepartureCity}</td>
                    <td>{flight.ArrivalCity}</td>
                    <td>{flight.DateOfDeparture}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="col-2"></div>
        </div>
      </div>
    );
  }
}

export default FlightList;
