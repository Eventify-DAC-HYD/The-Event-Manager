import { useState } from "react";
import axios from "axios";
import add_url from "../api/api1";

export default function Userinfo() {
  let [fname, setFname] = useState("");
  let [email, setEmail] = useState("");
  let [mname, setMname] = useState("");
  let [lname, setLname] = useState("");
  let [id, setId] = useState("");

  let handlefname = (e) => setFname(e.target.value);
  let handlemname = (e) => setMname(e.target.value);
  let handlelname = (e) => setLname(e.target.value);
  let handleemail = (e) => setEmail(e.target.value);
  let handleid = (e) => setId(e.target.value);

  let data = {
    fName: fname,
    mName: mname,
    lName: lname,
    email: email,
    flight: {
      flightId: id,
    },
  };
  let addPassanger = async () => {
    await axios.post(`${add_url}/addpassenger`, data);
  };
  return (
    <div className="container-fluid">
      <div className="row vh-100">
        <div className="col-3"></div>
        <div className="col-6 ">
          <div className="flex marginTop:3px marginBottom: 3px">
            <div>
              <label for="name" className="form-label fs-5">
                Enter First Name
              </label>
              <input
                type="text"
                className="form-control w-75 mb-3"
                id="name"
                name="name"
                placeholder="First Name"
                onChange={handlefname}
                value={fname}
                required
              />
            </div>
            <div>
              <label for="name" className="form-label fs-5">
                Enter Middle Name
              </label>
              <input
                type="text"
                name="name"
                className="form-control w-75 mb-3"
                placeholder="Middle Name"
                onChange={handlemname}
                value={mname}
                required
              />
            </div>
            <div>
              <label for="name" className="form-label fs-5">
                Enter Last Name
              </label>
              <input
                type="text"
                name="password"
                className="form-control w-75 mb-3"
                placeholder="Last Name"
                onChange={handlelname}
                value={lname}
                required
              />
            </div>
            <div>
              <label for="email" className="form-label fs-5">
                Email-ID
              </label>
              <input
                type="text"
                name="email"
                className="form-control w-75 mb-3"
                placeholder="Enter Email"
                onChange={handleemail}
                value={email}
                required
              />
            </div>
            <div>
              <label for="name" className="form-label fs-5">
                Enter Flight ID
              </label>
              <input
                type="text"
                name="name"
                className="form-control"
                placeholder="Flight-Id"
                onChange={handleid}
                value={id}
                required
              />
            </div>
            <div>
              <input type="button" value="book" onClick={addPassanger} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
