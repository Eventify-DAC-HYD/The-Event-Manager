import axios from "axios";

const base_url = "http://localhost:8080/updateflight";

class FlightService {
  updateFlight(airline_flight, flightId) {
    return axios.put(base_url + "/" + flightId, airline_flight);
  }
  getFlightById(flightId) {
    return axios.get(base_url + "/" + flightId);
  }
}

export default new FlightService();
