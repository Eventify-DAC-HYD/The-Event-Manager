import React, { Component } from "react";

class UserList extends Component {
  constructor() {
    super();

    this.state = {
      Users: [],
    };
  }
  render() {
    return (
      <div>
        <h2 className="text-center">User List</h2>
        <div className="row">
          <div className="col-2"></div>
          <div className="col-8">
            <table className="table table-sriped table-bordered">
              <thead>
                <tr>
                  <th>First Name</th>
                  <th>middle Name</th>
                  <th>Last Name</th>
                  <th>Email</th>

                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {/* {this.state.Flights.map((flight) => (
                <tr key="{user.id}">
                  <td>{user.fname}</td>
                  <td>{user.mnae}</td>
                  <td>{user.lname}</td>
                  <td>{user.email}</td>
                </tr>
              ))} */}
              </tbody>
            </table>
          </div>
          <div className="col-2"></div>
        </div>
      </div>
    );
  }
}

export default UserList;
