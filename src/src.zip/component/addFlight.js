import React from "react";
import { useState } from "react";
import axios from "axios";
import add_url from "../api/api1";

export default function Addflight() {
  let [operatingAirlines, setOperatingAirlines] = useState("");
  let [departureCity, setDepartureCity] = useState("");
  let [arrivalCity, setArrivalCity] = useState("");
  let [dateOfDeparture, setDateOfDeparture] = useState("");

  let handlefname = (e) => setOperatingAirlines(e.target.value);
  let handlemname = (e) => setDepartureCity(e.target.value);
  let handlelname = (e) => setArrivalCity(e.target.value);
  let handleemail = (e) => setDateOfDeparture(e.target.value);

  let data = {
    operatingAirlines: operatingAirlines,
    departureCity: departureCity,
    arrivalCity: arrivalCity,
    dateOfDeparture: dateOfDeparture,
  };

  let addFlights = async () => {
    await axios.post(`${add_url}/enterflightdetails`, data);
  };
  return (
    <div className="container-fluid">
      <div className="row vh-100">
        <div className="col-3"></div>
        <div className="col-6 ">
          <div className="flex marginTop:3px marginBottom: 3px">
            <div>
              <label for="name" className="form-label fs-5">
                Enter Airlines
              </label>
              <input
                type="text"
                className="form-control w-75 mb-3"
                id="name"
                name="name"
                placeholder="Enter Airline"
                onChange={handlefname}
                value={operatingAirlines}
                required
              />
            </div>
            <div>
              <label for="name" className="form-label fs-5">
                Enter Ddeparture cit
              </label>
              <input
                type="text"
                name="name"
                className="form-control w-75 mb-3"
                placeholder="Departure city"
                onChange={handlemname}
                value={departureCity}
                required
              />
            </div>
            <div>
              <label for="name" className="form-label fs-5">
                Enter Arrival city
              </label>
              <input
                type="text"
                name="password"
                className="form-control w-75 mb-3"
                placeholder="Arrival city"
                onChange={handlelname}
                value={arrivalCity}
                required
              />
            </div>
            <div>
              <label for="name" className="form-label fs-5">
                Enter Departure date
              </label>
              <input
                type="text"
                name="name"
                className="form-control w-75 mb-3"
                placeholder="Date of departure"
                onChange={handleemail}
                value={dateOfDeparture}
                required
              />
            </div>

            <div>
              <input type="button" value="save" onClick={addFlights} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
