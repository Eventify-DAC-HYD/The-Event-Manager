import React from "react";

import { BrowserRouter, Router, Route, Routes, Link } from "react-router-dom";
export default function HomeSuport() {
  return (
    <div>
      <div className="row">
        <div className="col-12 bg-primary text-light p-2 fs-2 flex d-flex">
          <div className=" row ms-4 vh-50 wh-75  ">
            <div className="col">
              <Link
                to="/"
                className="text-decoration-none text-light fs-5 mx-4 text-light p-2 fs-2 mb-2"
              >
                flyWings
              </Link>
            </div>

            <div className="col btn btn-secondary me-2">
              <Link
                to="/Register"
                className="text-decoration-none text-light fs-5"
              >
                Register
              </Link>
            </div>

            <div className="col btn btn-secondary me-2">
              <Link to="/" className="text-decoration-none text-light fs-5">
                Log in
              </Link>
            </div>
            <div className="col btn btn-secondary">
              <Link
                to="/allflight"
                className="text-decoration-none text-light fs-5"
              >
                CheckFlights
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
