import { Link } from "react-router-dom";
import Mycom from "./Navbar";
import React, { useEffect, useState } from "react";
import swal from "sweetalert2";
import axios from "axios";
import add_url from "../api/api1";

export default function Register() {
  useEffect(() => {
    document.title = "Register";
  }, []);

  let [Username, setUsername] = useState("");
  let [Email, setEmail] = useState("");
  let [password, setpassword] = useState("");
  let [Conpassword, setConpassword] = useState("");
  let [phone, setphone] = useState("");

  let handlename = (e) => setUsername(e.target.value);
  let handleEmail = (e) => setEmail(e.target.value);
  let handlePassword = (e) => setpassword(e.target.value);
  let handleconPassword = (e) => setConpassword(e.target.value);

  let handlePhone = (e) => setphone(e.target.value);
  let data = {
    name: Username,
    email: Email,
    password: password,
    phone: phone,
  };

  let comparepassword = () => {
    if (
      password === "" ||
      password.search(
        /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,20}$/
      ) < 0 ||
      password.length < 6
    ) {
      document.getElementById("password").classList.add("is-invalid");
      setpassword(
        "Enter a password with atleast 8 characters and must include 1 capital, 1 number and 1 special character"
      );
    } else if (password !== Conpassword) {
      document.getElementById("conpassword").classList.add("is-invalid");
      setConpassword("Password mismatch.");
    }
  };

  let validate = async () => {
    if (
      Username === "" ||
      Email === "" ||
      password === "" ||
      Conpassword === "" ||
      phone === ""(password !== Conpassword)
    ) {
      swal.fire({
        icon: "erro",
        title: "arreeeee!!!",
        text: "All Fields required",
      });
      return;
    }
    await axios
      .post(`${add_url}/register`, data)
      .then((response) => {
        swal.fire({
          icon: "success",
          title: "Hurreh!!!",
          text: "You have registered successfully ",
        });
      })
      .then(function () {
        window.location = "/";
      });

    setUsername("");
    setEmail("");
    setpassword("");
    setConpassword("");
    setphone("");
  };

  return (
    <div>
      <Mycom />
      <div className="row vh-100">
        <div className="col-3"></div>
        <div className="col-6 ">
          <div className="flex marginTop:3px marginBottom: 3px">
            <input
              type="text"
              className="form-control w-75 mb-3"
              id="name"
              name="name"
              placeholder="Full name"
              onChange={handlename}
              value={Username}
              required
            />
            <input
              type="text"
              name="email"
              className="form-control w-75 mb-3"
              placeholder="Enter Email"
              onChange={handleEmail}
              value={Email}
              required
            />
            <input
              type="text"
              name="password"
              className="form-control w-75 mb-3"
              placeholder="Enter Password"
              onChange={handlePassword}
              onKeyUp={comparepassword}
              value={password}
              required
            />
            <input
              type="text"
              name="conpassword"
              className="form-control w-75 mb-3"
              placeholder="Confirm Password"
              onChange={handleconPassword}
              value={Conpassword}
              required
            />
            <input
              type="text"
              className="form-control w-75 mb-3"
              name="number"
              placeholder="Enter phone number "
              onChange={handlePhone}
              value={phone}
              required
            />
          </div>
          <div className="marginTop: 5px">
            <input type="button" value="Register" onClick={validate} />
            <Link to="/" class="text-decoration-none fs-5 ms-3 ">
              Already Registered | Log in here
            </Link>
          </div>
          <div className="col-3"></div>
        </div>
      </div>
    </div>
  );
}
